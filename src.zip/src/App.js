import React from 'react';
import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Home from './component/pages/Home';
import About from './component/pages/About';
import Contact from './component/pages/Contact';
import Navbars from './component/layout/Navbars';
import PageNoteFound from './component/pages/PageNotFound'; 
import AddUser from './component/user/AddUser'
import { BrowserRouter as Router, Route, Switch} from "react-router-dom";

function App() {
  return (
    <Router>
      <div className="App">
      <Navbars />

      <Switch>
        <Route exact path='/' component={Home} />
        <Route  path='/abouts' component={About} />
        <Route  path='/contacts' component={Contact} />
        <Route  path='/add' component={AddUser} />

        <Route   component={PageNoteFound} />

        </Switch>

    </div>
    </Router>
  );
}

export default App;
