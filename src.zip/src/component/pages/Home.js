import React, { useState,useEffect } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

const Home = ()=>{
  const [users,setUser]=useState([]);

  const userss = [
              {
                name:"kkkkkkkk",
                username:"llllllllllllll",
                email:"kk@gmai.co",
                phone:"789641230",
                website:"wwww.kk.co"

              },
              {
                name:"kkkkkkkk",
                username:"llllllllllllll",
                email:"kk@gmai.co",
                phone:"789641230",
                website:"wwww.kk.co"
              },
              {
                name:"kkkkkkkk",
                username:"llllllllllllll",
                email:"kk@gmai.co",
                phone:"789641230",
                website:"wwww.kk.co"
              },
              {
                name:"kkkkkkkk",
                username:"llllllllllllll",
                email:"kk@gmai.co",
                phone:"789641230",
                website:"wwww.kk.co"
              }
  ]

  useEffect(() => {
   
    loadUsers();
    console.log("my name krishna ji")
  });

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:3003/users");
      setUser(result.data);

      console.log(result);
  }
    return(
      <table class="table">
      <thead>
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Full-name</th>
          <th scope="col">username</th>
          <th scope="col">email</th>
          <th scope="col">phone</th>
          <th scope="col">website</th>
          {/* <th scope="col">city</th> */}
          {/* <th scope="col">catchPhrase</th> */}
          <th>Action</th>

        </tr>
      </thead>
      <tbody>
       {
         userss && userss.map((user,index)=>(
         <tr>
            <th scope="row"> {index + 1} </th>
          <td>{user.name}</td>
          <td>{user.username}</td>
          <td>{user.email}</td>
          <td>{user.phone}</td>
          <td>{user.website}</td> 
          {/* <td>{user.address.city}</td> */}
          {/* <td>{user.company.catchPhrase}</td>*/}
          <td> 
              <Link className="btn  btn-primary buttn">View</Link>
              <Link className="btn btn-info buttn">Edit</Link>
              <Link className="btn btn-danger buttn">Delete</Link>
          </td>
          </tr>
          
          ))
       }
      </tbody>
    </table>
    )
}
export default Home