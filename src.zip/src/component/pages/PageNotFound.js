import React from 'react';

const PageNoteFound =()=>{
    return(
        <div classname="pagenotfound">

            <h1 className="dispaly-1">  pageNotfound</h1>
        </div>
    )

}

export default PageNoteFound